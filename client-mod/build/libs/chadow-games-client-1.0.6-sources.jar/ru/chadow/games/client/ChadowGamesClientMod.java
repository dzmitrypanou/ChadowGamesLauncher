package ru.chadow.games.client;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.class_4325;
import net.minecraft.class_442;
import net.minecraft.class_500;

public final class ChadowGamesClientMod implements ClientModInitializer {
    public static final String MOD_ID = "chadow_games_client";
    public static final String BRAND_NAME = "Chadow Games";

    private static boolean inGameSession;

    @Override
    public void onInitializeClient() {
        inGameSession = false;
    }

    public static void markInGame() {
        inGameSession = true;
    }

    public static boolean isInGameSession() {
        return inGameSession;
    }

    public static boolean shouldBlockScreen(net.minecraft.class_437 screen) {
        if (!inGameSession) {
            return false;
        }

        return screen instanceof class_442
                || screen instanceof class_500
                || screen instanceof class_4325;
    }
}
