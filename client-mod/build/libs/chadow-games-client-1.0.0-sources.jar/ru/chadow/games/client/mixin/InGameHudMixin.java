package ru.chadow.games.client.mixin;

import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.chadow.games.client.ChadowGamesClientMod;

@Mixin(class_329.class)
public abstract class InGameHudMixin {
    @Shadow
    @Final
    private class_310 minecraft;

    @Shadow
    @Final
    private class_327 font;

    @Inject(method = "render", at = @At("RETURN"))
    private void chadow$renderBrand(class_332 graphics, class_9779 tick, CallbackInfo ci) {
        if (this.minecraft.field_1687 == null || this.minecraft.field_1755 != null) {
            return;
        }

        String title = ChadowGamesClientMod.BRAND_NAME;
        int padding = 8;
        int textWidth = this.font.method_1727(title);
        int barWidth = textWidth + padding * 2;
        int barHeight = 16;
        int x = (graphics.method_51421() - barWidth) / 2;
        int y = 4;

        graphics.method_25294(x, y, x + barWidth, y + barHeight, 0xCC0A1022);
        graphics.method_25294(x, y, x + barWidth, y + 1, 0xFF36E0FF);
        graphics.method_51433(this.font, title, x + padding, y + 4, 0xFFE8F2FF, true);
    }
}
