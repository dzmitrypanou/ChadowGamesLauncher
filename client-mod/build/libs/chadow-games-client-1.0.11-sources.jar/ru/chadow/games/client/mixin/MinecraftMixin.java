package ru.chadow.games.client.mixin;

import net.minecraft.class_1041;
import net.minecraft.class_310;
import net.minecraft.class_433;
import net.minecraft.class_437;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.chadow.games.client.ChadowGamesClientMod;

@Mixin(class_310.class)
public abstract class MinecraftMixin {
    @Shadow
    public class_638 level;

    @Shadow
    public class_437 screen;

    @Shadow
    public class_1041 window;

    @Shadow
    public abstract void setScreen(class_437 screen);

    @Shadow
    public abstract void execute(Runnable task);

    @Inject(method = "setScreen", at = @At("HEAD"), cancellable = true)
    private void chadow$blockMenus(class_437 screen, CallbackInfo ci) {
        if (screen == null || !ChadowGamesClientMod.shouldBlockScreen(screen)) {
            return;
        }

        ci.cancel();
        class_310 client = (class_310) (Object) this;
        client.execute(() -> {
            ChadowGamesClientMod.requestQuit();
            client.method_1592();
        });
    }

    @Inject(method = "stop", at = @At("HEAD"), cancellable = true)
    private void chadow$guardStop(CallbackInfo ci) {
        if (ChadowGamesClientMod.consumeQuitRequest()) {
            return;
        }

        if (this.window != null && this.window.method_22093()) {
            return;
        }

        ci.cancel();

        if (this.level != null && this.screen == null) {
            this.setScreen(new class_433(false));
        }
    }

    @Inject(method = "pauseGame", at = @At("RETURN"))
    private void chadow$ensurePauseOpened(boolean pauseOnly, CallbackInfo ci) {
        if (this.level != null && this.screen == null) {
            this.setScreen(new class_433(pauseOnly));
        }
    }
}
