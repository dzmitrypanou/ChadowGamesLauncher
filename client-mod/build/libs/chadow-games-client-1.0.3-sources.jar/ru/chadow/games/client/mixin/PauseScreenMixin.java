package ru.chadow.games.client.mixin;

import net.minecraft.class_310;
import net.minecraft.class_4185;
import net.minecraft.class_433;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_433.class)
public abstract class PauseScreenMixin {
    @Inject(method = "createPauseMenu", at = @At("RETURN"))
    private void chadow$customizePauseMenu(CallbackInfo ci) {
        class_433 screen = (class_433) (Object) this;
        class_310 minecraft = class_310.method_1551();

        for (var child : screen.method_25396()) {
            if (!(child instanceof class_4185 button)) {
                continue;
            }

            String text = button.method_25369().getString().toLowerCase();
            if (isDisconnectLabel(text)) {
                ((ButtonAccessor) button).chadow$setOnPress(pressed -> minecraft.method_1592());
                continue;
            }

            if (isTitleMenuLabel(text)) {
                button.field_22764 = false;
                button.field_22763 = false;
            }
        }
    }

    private static boolean isDisconnectLabel(String text) {
        return text.contains("disconnect")
                || text.contains("отключ")
                || text.contains("отсоедин");
    }

    private static boolean isTitleMenuLabel(String text) {
        return text.contains("title")
                || text.contains("titl")
                || text.contains("главн")
                || text.contains("save and quit")
                || (text.contains("сохран") && text.contains("выйти"));
    }
}
