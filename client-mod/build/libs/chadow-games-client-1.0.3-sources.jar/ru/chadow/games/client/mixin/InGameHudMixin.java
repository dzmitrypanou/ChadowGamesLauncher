package ru.chadow.games.client.mixin;

import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.chadow.games.client.ChadowGamesClientMod;

@Mixin(class_329.class)
public abstract class InGameHudMixin {
    private static final class_2960 LOGO_TEXTURE = class_2960.method_60655(
            ChadowGamesClientMod.MOD_ID,
            "textures/gui/logo.png"
    );

    @Shadow
    @Final
    private class_310 minecraft;

    @Inject(method = "render", at = @At("RETURN"))
    private void chadow$renderBrand(class_332 graphics, class_9779 tick, CallbackInfo ci) {
        if (this.minecraft.field_1687 == null || this.minecraft.field_1755 != null) {
            return;
        }

        String title = ChadowGamesClientMod.BRAND_NAME;
        int padding = 8;
        int logoSize = 12;
        int gap = 6;
        int textWidth = this.minecraft.field_1772.method_1727(title);
        int barWidth = padding + logoSize + gap + textWidth + padding;
        int barHeight = 16;
        int x = (graphics.method_51421() - barWidth) / 2;
        int y = 4;

        graphics.method_25294(x, y, x + barWidth, y + barHeight, 0xCC0A1022);
        graphics.method_25294(x, y, x + barWidth, y + 1, 0xFF36E0FF);
        graphics.method_70845(LOGO_TEXTURE, x + padding, y + 2, logoSize, logoSize, 0.0F, 0.0F, 1.0F, 1.0F);
        graphics.method_51433(this.minecraft.field_1772, title, x + padding + logoSize + gap, y + 4, 0xFFE8F2FF, true);
    }
}
