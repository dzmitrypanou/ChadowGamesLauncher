package ru.chadow.games.client.mixin;

import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_419;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_419.class)
public abstract class DisconnectedScreenMixin {
    @Inject(method = "init", at = @At("RETURN"))
    private void chadow$hideTitleButton(CallbackInfo ci) {
        class_419 screen = (class_419) (Object) this;
        for (var child : screen.method_25396()) {
            if (!(child instanceof class_4185 button)) {
                continue;
            }
            class_2561 message = button.method_25369();
            String text = message.getString().toLowerCase();
            if (text.contains("title") || text.contains("главн") || text.contains("titl")) {
                button.field_22764 = false;
                button.field_22763 = false;
            }
        }
    }
}
