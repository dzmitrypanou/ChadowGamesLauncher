package ru.chadow.games.client.mixin;

import net.minecraft.class_4185;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_4185.class)
public interface ButtonAccessor {
    @Accessor("onPress")
    void chadow$setOnPress(class_4185.class_4241 onPress);
}
