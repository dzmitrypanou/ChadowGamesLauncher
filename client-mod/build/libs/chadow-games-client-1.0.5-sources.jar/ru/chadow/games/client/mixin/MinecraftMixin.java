package ru.chadow.games.client.mixin;

import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.chadow.games.client.ChadowGamesClientMod;

@Mixin(class_310.class)
public abstract class MinecraftMixin {
    @Shadow
    public class_638 level;

    @Inject(method = "tick", at = @At("HEAD"))
    private void chadow$trackSession(CallbackInfo ci) {
        if (this.level != null) {
            ChadowGamesClientMod.markInGame();
        }
    }

    @Inject(method = "setScreen", at = @At("HEAD"), cancellable = true)
    private void chadow$blockMenus(class_437 screen, CallbackInfo ci) {
        if (screen != null && ChadowGamesClientMod.shouldBlockScreen(screen)) {
            ci.cancel();
        }
    }

    @Inject(method = "disconnectWithSavingScreen", at = @At("HEAD"), cancellable = true)
    private void chadow$quitLauncherOnLeaveWorld(CallbackInfo ci) {
        class_310 client = (class_310) (Object) this;
        client.method_1592();
        ci.cancel();
    }
}
