package ru.chadow.games.client.mixin;

import net.minecraft.class_310;
import net.minecraft.class_4185;
import net.minecraft.class_419;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.chadow.games.client.ChadowGamesClientMod;

@Mixin(class_419.class)
public abstract class DisconnectedScreenMixin {
    @Inject(method = "init", at = @At("RETURN"))
    private void chadow$quitInsteadOfLobby(CallbackInfo ci) {
        class_419 screen = (class_419) (Object) this;
        class_310 minecraft = class_310.method_1551();

        for (var child : screen.method_25396()) {
            if (!(child instanceof class_4185 button)) {
                continue;
            }

            String text = button.method_25369().getString();
            if (ChadowGamesClientMod.isReportButtonLabel(text)) {
                continue;
            }

            ((ButtonAccessor) button).chadow$setOnPress(btn -> {
                ChadowGamesClientMod.requestQuit();
                minecraft.method_1592();
            });
        }
    }
}
