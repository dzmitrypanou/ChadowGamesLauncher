package ru.chadow.games.client.mixin;

import net.minecraft.class_310;
import net.minecraft.class_433;
import net.minecraft.class_437;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.chadow.games.client.ChadowGamesClientMod;

@Mixin(class_310.class)
public abstract class MinecraftMixin {
    @Shadow
    public class_638 level;

    @Shadow
    public class_437 screen;

    @Shadow
    public abstract void setScreen(class_437 screen);

    @Inject(method = "tick", at = @At("HEAD"))
    private void chadow$trackWorld(CallbackInfo ci) {
        if (this.level != null) {
            ChadowGamesClientMod.markInWorld();
        }
    }

    @Inject(method = "setScreen", at = @At("HEAD"), cancellable = true)
    private void chadow$blockMenus(class_437 screen, CallbackInfo ci) {
        if (screen == null || !ChadowGamesClientMod.shouldBlockScreen(screen)) {
            return;
        }

        ci.cancel();

        if (this.level != null) {
            if (!(this.screen instanceof class_433)) {
                this.setScreen(new class_433(false));
            }
            return;
        }

        if (ChadowGamesClientMod.consumeQuitRequest()) {
            ((class_310) (Object) this).method_1592();
        }
    }
}
