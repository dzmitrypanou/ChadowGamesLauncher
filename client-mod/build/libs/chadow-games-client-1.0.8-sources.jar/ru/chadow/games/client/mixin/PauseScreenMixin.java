package ru.chadow.games.client.mixin;

import net.minecraft.class_310;
import net.minecraft.class_4185;
import net.minecraft.class_433;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.chadow.games.client.ChadowGamesClientMod;

@Mixin(class_433.class)
public abstract class PauseScreenMixin {
    @Inject(method = "createPauseMenu", at = @At("RETURN"))
    private void chadow$customizePauseMenu(CallbackInfo ci) {
        class_433 screen = (class_433) (Object) this;
        class_310 minecraft = class_310.method_1551();

        for (var child : screen.method_25396()) {
            if (!(child instanceof class_4185 button)) {
                continue;
            }

            String text = button.method_25369().getString();
            String lowered = text.toLowerCase();

            if (isTitleMenuLabel(lowered)) {
                button.field_22764 = false;
                button.field_22763 = false;
                continue;
            }

            if (ChadowGamesClientMod.isDisconnectButtonLabel(text)) {
                ((ButtonAccessor) button).chadow$setOnPress(btn -> minecraft.method_1592());
            }
        }
    }

    private static boolean isTitleMenuLabel(String text) {
        return text.contains("title")
                || text.contains("titl")
                || text.contains("главн")
                || text.contains("save and quit")
                || (text.contains("сохран") && text.contains("выйти"));
    }
}
