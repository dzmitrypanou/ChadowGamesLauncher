package ru.chadow.games.client;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.class_4325;
import net.minecraft.class_442;
import net.minecraft.class_500;
import java.util.Locale;

public final class ChadowGamesClientMod implements ClientModInitializer {
    public static final String MOD_ID = "chadow_games_client";
    public static final String BRAND_NAME = "Chadow Games";

    private static boolean inGameSession;

    @Override
    public void onInitializeClient() {
        inGameSession = false;
    }

    public static void markInGame() {
        inGameSession = true;
    }

    public static void resetSession() {
        inGameSession = false;
    }

    public static boolean isInGameSession() {
        return inGameSession;
    }

    public static boolean shouldBlockScreen(net.minecraft.class_437 screen) {
        if (!inGameSession) {
            return false;
        }

        return screen instanceof class_442
                || screen instanceof class_500
                || screen instanceof class_4325;
    }

    public static boolean isLobbyNavigationLabel(String text) {
        String lowered = text.toLowerCase(Locale.ROOT);
        return lowered.contains("title")
                || lowered.contains("titl")
                || lowered.contains("главн")
                || lowered.contains("menu")
                || lowered.contains("меню")
                || lowered.contains("список")
                || lowered.contains("server list")
                || lowered.contains("to menu")
                || lowered.contains("к сервер");
    }

    public static boolean isDisconnectButtonLabel(String text) {
        String lowered = text.toLowerCase(Locale.ROOT);
        return lowered.contains("disconnect")
                || lowered.contains("отключ");
    }

    public static boolean isReportButtonLabel(String text) {
        String lowered = text.toLowerCase(Locale.ROOT);
        return lowered.contains("report")
                || lowered.contains("отчёт")
                || lowered.contains("отчет")
                || lowered.contains("bug")
                || lowered.contains("папк");
    }
}
