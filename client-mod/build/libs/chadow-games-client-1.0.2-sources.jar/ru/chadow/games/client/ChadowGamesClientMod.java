package ru.chadow.games.client;

import net.fabricmc.api.ClientModInitializer;

public final class ChadowGamesClientMod implements ClientModInitializer {
    public static final String MOD_ID = "chadow_games_client";
    public static final String BRAND_NAME = "Chadow Games";

    private static boolean inGameSession;

    @Override
    public void onInitializeClient() {
        inGameSession = false;
    }

    public static void markInGame() {
        inGameSession = true;
    }

    public static boolean isInGameSession() {
        return inGameSession;
    }

    public static boolean shouldBlockScreen(net.minecraft.class_437 screen) {
        if (screen instanceof net.minecraft.class_433) {
            return true;
        }
        if (screen instanceof net.minecraft.class_442 && inGameSession) {
            return true;
        }
        if (screen instanceof net.minecraft.class_419) {
            return false;
        }
        return false;
    }
}
