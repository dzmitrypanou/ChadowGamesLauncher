package ru.chadow.games.client;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import net.minecraft.class_310;
import net.minecraft.class_412;
import net.minecraft.class_437;
import net.minecraft.class_639;
import net.minecraft.class_642;

public final class PendingServerConnect {
    static final String CONNECT_FILE = "chadow-connect.txt";
    private static final int CONNECT_DELAY_TICKS = 100;

    private static String address;
    private static int ticksRemaining = -1;
    private static boolean connecting;

    private PendingServerConnect() {
    }

    public static void onClientTick(class_310 client) {
        if (connecting) {
            return;
        }

        if (address == null) {
            readPendingAddress(client);
            return;
        }

        if (ticksRemaining > 0) {
            ticksRemaining--;
            return;
        }

        if (!isClientReady(client)) {
            return;
        }

        String target = address;
        address = null;
        ticksRemaining = -1;
        connecting = true;
        try {
            connect(client, target);
        } finally {
            connecting = false;
        }
    }

    private static void readPendingAddress(class_310 client) {
        Path path = client.field_1697.toPath().resolve(CONNECT_FILE);
        if (!Files.isRegularFile(path)) {
            return;
        }

        try {
            String value = Files.readString(path).trim();
            Files.deleteIfExists(path);
            if (value.isEmpty()) {
                return;
            }
            address = value;
            ticksRemaining = CONNECT_DELAY_TICKS;
        } catch (IOException ignored) {
        }
    }

    private static boolean isClientReady(class_310 client) {
        return client.method_18506() == null
                && client.field_1755 != null
                && client.field_1724 == null
                && client.field_1687 == null;
    }

    private static void connect(class_310 client, String target) {
        class_639 serverAddress = class_639.method_2950(target);
        class_642 serverData = new class_642(ChadowGamesClientMod.BRAND_NAME, target, class_642.class_8678.field_45611);
        class_437 screen = client.field_1755;
        if (screen == null) {
            return;
        }
        class_412.method_36877(screen, client, serverAddress, serverData, false, null);
    }
}
